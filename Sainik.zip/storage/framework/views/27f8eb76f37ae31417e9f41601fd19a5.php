<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(asset('vendors/feather/feather.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/ti-icons/css/themify-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/css/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo e(asset('vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/ti-icons/css/themify-icons.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/select.dataTables.min.css')); ?>">  
  <link rel="stylesheet" href="<?php echo e(asset('vendors/select2/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/select2-bootstrap-theme/select2-bootstrap.min.css')); ?>">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('css/vertical-layout-light/style.css')); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" />
</head>
<body>
<div class="container-scroller">
    <?php echo $__env->make('layouts.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">
      <?php echo $__env->make('layouts.includes.sidebar-student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="main-panel">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <!-- main-panel ends -->
    </div>   
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="https://kit.fontawesome.com/beb4bd70e2.js" crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="<?php echo e(asset('vendors/chart.js/Chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
  <script src="<?php echo e(asset('js/dataTables.select.min.js')); ?>"></script>

  <script src="<?php echo e(asset('vendors/typeahead.js/typeahead.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendors/select2/select2.min.js')); ?>"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(asset('js/template.js')); ?>"></script>
  <script src="<?php echo e(asset('js/settings.js')); ?>"></script>
  <script src="<?php echo e(asset('js/todolist.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
  <script src="<?php echo e(asset('js/Chart.roundedBarCharts.js')); ?>"></script>
  <!-- End custom js for this page-->

  <script src="<?php echo e(asset('js/file-upload.js')); ?>"></script>
  <script src="<?php echo e(asset('js/typeahead.js')); ?>"></script>
  <script src="<?php echo e(asset('js/select2.js')); ?>"></script>
  <?php echo $__env->yieldContent('page_script'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\Sainik\resources\views/layouts/student.blade.php ENDPATH**/ ?>