
<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <div class="row">
      <div class="col-md-5 grid-margin">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Add Test</h4>
            <p class="card-description">
              Add New Test
              <?php echo e(session()->has('exam_id') ? session('exam_id') : ''); ?>

            </p>
            <?php if(session()->has('error')): ?>
              <div class="alert alert-danger"><?php echo e(session('error')); ?></div>  
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
              <div class="alert alert-success"><?php echo e(session('success')); ?></div>  
            <?php endif; ?>

            <form class="" method='post' enctype="multipart/form-data" 
              action="<?php echo e(($test && $test->id) ? route('admin.test.update', [$test->id]) : route('admin.test.save')); ?>"
            >
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="subject">Subject Name</label>
                <select class="form-control" id="subject" name="subject">
                  <option value="">Select</option>
                  <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($value); ?>"
                    <?php if(($test && $test->subject_name==$value) || (session()->has('test_subject') && session('test_subject') == $value)): ?> selected <?php endif; ?>
                  >
                    <?php echo e($value); ?>

                  </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="que">Question.</label>
                <textarea class="form-control" id="que" rows="4" placeholder="Question" name="que"><?php echo e(($test && $test->que) ? $test->que : ''); ?></textarea>
                <input type="file" class="form-control"  name="quef"/>
                <?php $__errorArgs = ['que'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="o1">Option 1</label>
                <input type="text" class="form-control" id="o1" placeholder="Option 1" name="o1" value="<?php echo e(($test && $test->o1) ? $test->o1: ''); ?>">
                <input type="file" class="form-control"  name="o1f"/>
                <?php $__errorArgs = ['o1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="o2">Option 2</label>
                <input type="text" class="form-control" id="o2" placeholder="Option 2" name="o2" value="<?php echo e(($test && $test->o2) ? $test->o2: ''); ?>">
                <input type="file" class="form-control"  name="o2f"/>
                <?php $__errorArgs = ['o2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="o3">Option 3</label>
                <input type="text" class="form-control" id="o3" placeholder="Option 3" name="o3" value="<?php echo e(($test && $test->o3) ? $test->o3: ''); ?>" />
                <input type="file" class="form-control"  name="o3f"/>
                <?php $__errorArgs = ['o3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="o4">Option 4</label>
                <input type="text" class="form-control" id="o4" placeholder="Option 4" name="o4" value="<?php echo e(($test && $test->o4) ? $test->o4: ''); ?>">
                <input type="file" class="form-control" name="o4f"/>
                <?php $__errorArgs = ['o4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="right_answer">Right Answer</label>
                <input type="text" class="form-control" id="right_answer" placeholder="Right Answer" name="right_answer" value="<?php echo e(($test && $test->right_answer) ? $test->right_answer: ''); ?>">
                <?php $__errorArgs = ['right_answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="unseen_passage">Unseen Passage</label>
                <textarea type="text" class="form-control" id="unseen_passage" placeholder="Unseen Passage" name="unseen_passage"><?php echo e((($test && $test->unseen_passage) ? $test->unseen_passage: '')); ?> <?php echo e(((session()->has('unseen_passage') && session('unseen_passage')  && (!$test || !$test->unseen_passage)) ? session('unseen_passage'): '')); ?></textarea>
              </div>
              <div class="form-group">
                <label for="directions">Directions</label>
                <textarea type="text" class="form-control" id="directions" placeholder="Direction" name="directions"><?php echo e((($test && $test->directions) ? $test->directions: '')); ?> <?php echo e(((session()->has('directions') && session('directions')  && (!$test || !$test->directions)) ? session('directions'): '')); ?></textarea>
              </div>
              <div class="form-group">
                <label for="small_instructions">Small Instructions</label>
                <textarea type="text" class="form-control" id="small_instructions" placeholder="Small Instructions" name="small_instructions"><?php echo e((($test && $test->small_instructions) ? $test->small_instructions : '')); ?> <?php echo e(((session()->has('small_instructions') && session('small_instructions') && (!$test || !$test->small_instructions)) ? session('small_instructions'): '')); ?></textarea>
              </div>
              <button type="submit" class="btn btn-primary mr-2"><?php echo e(($test && $test->right_answer) ? 'Update' : 'Add'); ?></button>
              <a class="btn btn-light" href="<?php echo e(route('admin.test.form')); ?>">Reset</a>
            </form>
          </div>
        </div>
      </div>
      <div class="col-md-7 grid-margin">
        <div class="card">
            <div class="card-body">
              <h4 class="card-title">Test List</h4>
              <p class="card-description">
                List of all the test available.
              </p>
              <div class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>Action</th>
                      <th>Subject</th>
                      <th>Question Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $questionList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td style="line-height: 20px;">
                        <a href="<?php echo e(route('admin.test.form.edit', [$item->id])); ?>" class="btn btn-primary btn-sm">edit</a>
                        <br>
                        <a href="<?php echo e(route('admin.test.destroy',[$item->id])); ?>" class="btn btn-danger btn-sm">delete</a>
                      </td>
                      <td><?php echo e(ucfirst($item->subject_name)); ?></td>
                      <td style="line-height: 20px;">
                        <?php echo $item->question(); ?>

                        <br>
                        <?php echo $item->options(); ?>

                        <br>
                        <b style="color:#81cc7f"><?php echo e($item->rightAnswer()); ?></b>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <?php echo e($questionList->links()); ?>

              </div>
            </div>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Sainik\resources\views/test/form.blade.php ENDPATH**/ ?>