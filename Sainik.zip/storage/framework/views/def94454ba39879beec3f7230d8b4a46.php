<!DOCTYPE html>
<html>
<head>
    <title>Student Registration Confirmation</title>
</head>
<body>
    <h1>Student Registration Confirmation</h1>
    
    <p>Hello,</p>

    <p>A student has registered with the following details:</p>

    <ul>
        <li><strong>Name:</strong> <?php echo e($name); ?></li>
        <li><strong>Email:</strong> <?php echo e($email); ?></li>
        <li><strong>Password:</strong> <?php echo e($password); ?></li>
    </ul>
    
    <p>Thank you for using our platform!</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\Sainik\resources\views/mail/student_create.blade.php ENDPATH**/ ?>