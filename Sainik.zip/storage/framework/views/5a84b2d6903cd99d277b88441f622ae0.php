
<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <div class="row">
      <div class="col-md-7 grid-margin">
        <div class="card">
            <div class="card-body">
              <h4 class="card-title" style="display:flex;">
                <div style="display:flex;align-items:center;">Test List</div>
                <div class="ml-2">
                  <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Add From Excel
                  </button>
                </div>
              </h4>
              <p class="card-description">
                List of all the test available.
              </p>
              <div class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>Action</th>
                      <th>School</th>
                      <th>Name</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td style="line-height: 20px;">
                        <a href="<?php echo e(route('admin.exam.form.edit', [$item->id])); ?>" class="btn btn-info btn-sm">edit</a>
                        <button onclick="deleteEntry('<?php echo e(route('admin.exam.destroy',[$item->id])); ?>')" class="btn btn-danger btn-sm">delete</button>
                        <a href="<?php echo e(route('admin.test.form')); ?>?exam_id=<?php echo e($item->id); ?>" class="btn btn-primary btn-sm">Select</a>
                      </td>
                      <td style="line-height: 20px;">
                        <?php echo $item->school; ?>

                      </td>
                      <td>
                        <?php echo $item->name; ?>

                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
        </div>
      </div>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <form action="<?php echo e(route('admin.test.excel')); ?>" enctype="multipart/form-data" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Excel Upload</h5>
                      <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <input type="file" class="form-control" name="file">
                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm">Upload</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                  </div>
              </form>
          </div>
      </div>
  </div>
  <!-- End Modal -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sainik\resources\views/test/selectexam.blade.php ENDPATH**/ ?>