
<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="card" style="padding-left: 10px; padding-right: 10px;">
                <div class="card-body">
                <h4 class="card-title">Test List</h4>
                <p class="card-description">
                    <form action="<?php echo e(route('admin.test.list')); ?>">
                        <div class="form-group row">
                            <div class="col-3">
                                <input type="text" class="form-control" id="question" placeholder="Question" name="question" value="<?php echo e(request()->has('question') ? request()->question: ''); ?>">
                            </div>
                            <div class="col-3">
                                <button type="submit" class="btn btn-primary">Search</button>
                            </div>
                        </div>
                    </form>
                </p>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Action</th>
                                <th>Subject</th>
                                <th style="max-width:300px !important;">Question Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $questionList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('admin.test.form.edit', [$item->id])); ?>" class="btn btn-primary btn-sm">edit</a>
                                    <br>
                                    <a href="<?php echo e(route('admin.test.destroy',[$item->id])); ?>" class="btn btn-danger btn-sm">delete</a>
                                    <br>
                                    <!-- Button trigger modal -->
                                    <button 
                                        type="button" 
                                        class="btn btn-info btn-sm" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#exampleModal-<?php echo e($item->id); ?>"
                                    >
                                        Preview
                                    </button>
                                </td>
                                <td><?php echo e(ucfirst($item->subject_name)); ?></td>
                                <td style="line-height:22px; word-wrap:break-word; max-width:300px; overflow:hidden;">
                                    <p class="white-space: normal;"><?php echo $item->question(); ?></p>
                                    <br>
                                    <?php echo $item->options(); ?>

                                    <br>
                                    <b style="color:#81cc7f"><?php echo e($item->rightAnswer()); ?></b>
                                </td>
                                <td>
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Details</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div style="padding:20px" class="row">
                                                <h3 style="white-space: normal; margin-bottom: 20px;" class="col-12">
                                                    Que:<br>
                                                    <?php echo $item->que; ?>

                                                </h3>
                                                <?php if($item->quef): ?>
                                                <div class="col-12" 
                                                    style="height: 400px;"
                                                >
                                                    <img src="<?php echo e(asset('/storage/'.$item->quef)); ?>" 
                                                        style="width:inherit;height:100%;object-size:cover;border-radius: 0px;" 
                                                        alt=""
                                                    />
                                                </div>
                                                <?php endif; ?>
                                                <div class="col-12 row">
                                                    <div class="col-md-6">
                                                        <div class="form-group" style="line-height: 22px; font-size:20px;">
                                                            <?php echo e($item->qf1); ?>

                                                            <?php echo e($item->qf2); ?>

                                                            <?php echo e($item->qf3); ?>

                                                            <?php echo e($item->qf4); ?>

                                                            <?php echo $item->options(); ?>                                                         
                                                        </div>
                                                    </div>
                                                </div>
                                                <div style="color:#81cc7f; font-size: 20px;" class="col-12">
                                                    <?php echo e($item->rightAnswer()); ?>

                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                </div>
                <?php echo e($questionList->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sainik\resources\views/test/list.blade.php ENDPATH**/ ?>