
<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-5 grid-margin stretch-card">
              <div class="card scrollable-div"  >
                <div class="card-body">
                  <h4 class="card-title">Add Student</h4>
                  <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>  
                  <?php endif; ?>
                  <?php if(session()->has('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>  
                  <?php endif; ?>
                  <!-- <p class="card-description">
                    Basic form layout
                  </p> -->
                  <form class="forms-sample" method="post" action="<?php echo e(($student && $student->id) ?  route('admin.student.update',[$student->id]) : route('admin.student.add')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                      <label for="name">Name</label>
                      <input type="text" class="form-control" id="name" placeholder="Name" name='name' value="<?php echo e(($student && $student->name) ? $student->name: ''); ?>">
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="father_name">Father's name</label>
                      <input type="text" class="form-control" id="father_name" placeholder="Father Name" name="father_name" value="<?php echo e(($student && $student->father_name) ? $student->father_name: ''); ?>">
                      <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="email">Email</label>
                      <input type="email" class="form-control" id="email" placeholder="Email" name="email"value="<?php echo e(($student) ? $student->user->email: ''); ?>">
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="add_no">Admisson no.</label>
                      <input type="text" class="form-control" id="add_no" placeholder="Admission No" name="add_no" value="<?php echo e(($student && $student->add_no) ? $student->add_no: ''); ?>">
                      <?php $__errorArgs = ['add_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="class">Class</label>
                      <select class="form-control" id="class" name="class">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if($student && $student->class==$value): ?> selected <?php endif; ?>><?php echo e($value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                    <a class="btn btn-light" href="<?php echo e(route('admin.student.form')); ?>">Cancel</a>
                  </form>
                </div>
              </div>
            </div>
            <div class="col-md-7 grid-margin">
              <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Test List</h4>
                    <p class="card-description">
                      List of all the Students available.
                    </p>
                    <div class="table-responsive">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Father</th>
                            <th>Email</th>
                            <th>Addmission No</th>
                            <th>Class</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e(ucfirst($item->name)); ?></td>
                            <td><?php echo e(ucfirst($item->father_name)); ?></td>
                            <td><?php echo e($item->user->email ?? ''); ?></td>
                            <td><?php echo e($item->add_no); ?></td>
                            <td><?php echo e($item->class); ?></td>
                            <td>
                              <a href="<?php echo e(route('admin.student.form.edit', [$item->id])); ?>" class="btn btn-primary btn-sm">edit</a>
                              <a href="<?php echo e(route('admin.student.destroy',[$item->id])); ?>" class="btn btn-danger btn-sm">delete</a>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Sainik\resources\views/students/form.blade.php ENDPATH**/ ?>