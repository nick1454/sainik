
<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Student Test</h4>
                    <p class="card-description">
                        <a class="btn btn-info" href="?download=1<?php echo e(request()->has('id') && request()->id ? '&id='.request()->id : ''); ?>">
                            <i class="icon-excel menu-icon"></i>
                            Download
                        </a>
                    </p>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>UserName</th>
                                    <th>Exam</th>
                                    <th>Attempts No</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $testList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr onclick="openQuestionPaper(<?php echo e($test->id); ?>)">
                                    <td class="py-1">
                                        <?php echo e($test->user->name ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($test->exam->name ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($test->attempt_no ?? ''); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($testList->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_script'); ?>
<script>
    function openQuestionPaper(id)
    {
        console.log(id);
        window.location.href = "<?php echo e(route('admin.reports.studenttestquestion')); ?>"+'?id='+id;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sainik\resources\views/adminreports/student_test_attempt.blade.php ENDPATH**/ ?>