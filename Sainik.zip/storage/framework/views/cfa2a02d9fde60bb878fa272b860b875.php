
<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <div class="row">
      <div class="col-md-5 grid-margin">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Add Test</h4>
            <p class="card-description">
              Add New Test
            </p>
            <?php if(session()->has('error')): ?>
              <div class="alert alert-danger"><?php echo e(session('error')); ?></div>  
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
              <div class="alert alert-success"><?php echo e(session('success')); ?></div>  
            <?php endif; ?>

            <form class="" method='post' enctype="multipart/form-data" 
              action="<?php echo e(($exam && $exam->id) ? route('admin.exam.update', [$exam->id]) : route('admin.exam.save')); ?>"
            >
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="school">School</label>
                <select class="form-control" id="school" name="school">
                  <option value="">Select</option>
                  <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($value); ?>"
                    <?php if($exam && $exam->school==$value): ?> selected <?php endif; ?>
                  >
                    <?php echo e($value); ?>

                  </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['exam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="form-group">
                <label for="que">Name.</label>
                <input type="name" 
                  class="form-control" 
                  name="name" 
                  value="<?php echo e(($exam && $exam->name) ? $exam->name:''); ?>" 
                  placeholder="Name"
                />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <button type="submit" class="btn btn-primary mr-2">
                <?php echo e(($exam && $exam->id) ? 'Update' : 'Add'); ?>

              </button>
              <a class="btn btn-light" href="<?php echo e(route('admin.test.form')); ?>">Reset</a>
            </form>
          </div>
        </div>
      </div>
      <div class="col-md-7 grid-margin">
        <div class="card">
            <div class="card-body">
              <h4 class="card-title">Test List</h4>
              <p class="card-description">
                List of all the test available.
                <?php echo e($exam && $exam->name ? $exam->name : ''); ?>

              </p>
              <div class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>Action</th>
                      <th>School</th>
                      <th>Name</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td style="line-height: 20px;">
                        <a href="<?php echo e(route('admin.exam.form.edit', [$item->id])); ?>" class="btn btn-primary btn-sm">edit</a>
                        <br>
                        <button onclick="deleteEntry('<?php echo e(route('admin.exam.destroy',[$item->id])); ?>')" class="btn btn-danger btn-sm">delete</button>
                      </td>
                      <td style="line-height: 20px;">
                        <?php echo $item->school; ?>

                      </td>
                      <td>
                        <?php echo $item->name; ?>

                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Sainik\resources\views/exam/examform.blade.php ENDPATH**/ ?>