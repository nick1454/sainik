
<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Student Test Attempt</h4>
                    <p class="card-description">
                    </p>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>UserName</th>
                                    <th>Exam</th>
                                    <th>Questions Attempted</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $testList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="py-1">
                                        <?php echo e($test->user->name ?? ''); ?>

                                    </td>
                                    <td>
                                        <?php echo e($test->exam->name ?? ''); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.reports.studenttestquestion',[$test->exam->id])); ?>">
                                            <?php echo e($test->question_attempted ?? ''); ?>

                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sainik\resources\views/adminreports/student_test.blade.php ENDPATH**/ ?>